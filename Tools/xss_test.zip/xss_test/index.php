<!DOCTYPE html><!--STATUS OK--><html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>Welcome XSS challenges</title>
</head>
<body>
<h1 align=center>Welcome XSS challenges</h1>
<h3 align=center>开始XSS学习吧！</h3>
<a href=level1.php?name=test><center>Level 1</center></a>
<a href=level2.php><center>Level 2</center></a>
<a href=level3.php?name=test><center>Level 3</center></a>
<a href=level4.php?name=test><center>Level 4</center></a>
<a href=level5.php?name=test><center>Level 5</center></a>
<a href=level6.php?name=test><center>Level 6</center></a>
<a href=level7.php?name=test><center>Level 7</center></a>
<a href=level8.php?name=test><center>Level 8</center></a>
<a href=level9.php?name=test><center>Level 9</center></a>
<a href=level10.php?name=test><center>Level 10</center></a>
<a href=level11.php?name=test><center>Level 11</center></a>
<a href=level12.php?name=test><center>Level 12</center></a>
<a href=level13.php?name=test><center>Level 13</center></a>
<a href=level14.php?name=test><center>Level 14</center></a>
<a href=level15.php?name=test><center>Level 15</center></a>
<a href=level16.php?name=test><center>Level 16</center></a>
<a href=level17.php?name=test><center>Level 17</center></a>
<a href=level18.php?name=test><center>Level 18</center></a>
<a href=level19.php?name=test><center>Level 19</center></a>
<a href=level21.php?arg01=a&arg02=b><center>Level 20</center></a>
<a><center><img src=index.png></center></a>
</body>
</html>


